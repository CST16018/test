﻿Public Class Form1
    Dim speed As Integer
    Dim road(7) As PictureBox
    Dim Score As Integer = 0
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        speed = 3
        road(0) = PictureBox1
        road(1) = PictureBox2
        road(2) = PictureBox3
        road(3) = PictureBox4
        road(4) = PictureBox5
        road(5) = PictureBox6
        road(6) = PictureBox7
        road(7) = PictureBox8



    End Sub

    Private Sub RoadMover_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RoadMover.Tick
        For x As Integer = 0 To 7
            road(x).Top += speed
            If road(x).Top >= Me.Height Then
                road(x).Top = -road(x).Height
            End If
        Next
        If Score > 10 And Score < 20 Then
            speed = 5
        End If
        If Score > 20 And Score < 30 Then
            speed = 6
        End If
        If Score > 30 Then
            speed = 7
        End If
        Speed_Text.Text = "Speed" & speed
        If (Car.Bounds.IntersectsWith(EnemyCar1.Bounds)) Then
            gameOver()
        End If
        If (Car.Bounds.IntersectsWith(EnemyCar2.Bounds)) Then
            gameOver()
        End If
        If (Car.Bounds.IntersectsWith(EnemyCar3.Bounds)) Then
            gameOver()
            RoadMover.Stop()
            Enemy1_Mover.Stop()
            Enemy2_Mover.Stop()
            Enemy3_Mover.Stop()
        End If
    End Sub
    Private Sub gameOver()
        End_Text.Visible = True
        Replay_Button.Visible = True
        RoadMover.Stop()
        Enemy1_Mover.Stop()
        Enemy2_Mover.Stop()
        Enemy3_Mover.Stop()
    End Sub



    Private Sub Form1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Right Then
            Right_mover.Start()
        End If
        If e.KeyCode = Keys.Left Then
            Left_mover.Start()
        End If
    End Sub

    Private Sub Left_mover_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Left_mover.Tick
        If (Car.Location.X > 0) Then
            Car.Left -= 5
        End If

    End Sub

    Private Sub Right_mover_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Right_mover.Tick
        If (Car.Location.X < 270) Then
            Car.Left += 5
        End If
    End Sub

    Private Sub Form1_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        Right_mover.Stop()
        Left_mover.Stop()
    End Sub


    Private Sub Enemy1_Mover_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Enemy1_Mover.Tick
        EnemyCar1.Top += speed / 2
        If EnemyCar1.Top >= Me.Height Then
            Score += 1
            Score_Text.Text = "Score" & Score
            EnemyCar1.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + EnemyCar1.Height)
            EnemyCar1.Left = CInt(Math.Ceiling(Rnd() * 50)) + 0

        End If
    End Sub

    Private Sub Enemy2_Mover_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Enemy2_Mover.Tick
        EnemyCar2.Top += speed
        If EnemyCar2.Top >= Me.Height Then
            Score += 1
            Score_Text.Text = "Score" & Score
            EnemyCar2.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + EnemyCar2.Height)
            EnemyCar2.Left = CInt(Math.Ceiling(Rnd() * 50)) + 100
        End If
    End Sub

    Private Sub Enemy3_Mover_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Enemy3_Mover.Tick
        EnemyCar3.Top += speed * 3 / 2
        If EnemyCar3.Top >= Me.Height Then
            Score += 1
            Score_Text.Text = "Score" & Score
            EnemyCar3.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + EnemyCar3.Height)
            EnemyCar3.Left = CInt(Math.Ceiling(Rnd() * 100)) + 150
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Replay_Button.Click
        Score = 0
        Me.Controls.Clear()
        InitializeComponent()
        Form1_Load(e, e)
    End Sub
End Class
